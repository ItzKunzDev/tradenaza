"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { useToast } from "@/components/ui/use-toast"

type Balances = {
  [currency: string]: number
}

type Transaction = {
  id: string
  type: "buy" | "sell" | "deposit" | "withdrawal"
  asset: string
  amount: number
  price: number
  total: number
  timestamp: Date
}

interface WalletContextProps {
  balances: Balances
  transactions: Transaction[]
  addBalance: (currency: string, amount: number) => void
  subtractBalance: (currency: string, amount: number) => boolean
  executeTrade: (type: "buy" | "sell", asset: string, amount: number, price: number) => boolean
  getTransactions: () => Transaction[]
}

const WalletContext = createContext<WalletContextProps | undefined>(undefined)

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast()
  const [balances, setBalances] = useState<Balances>({
    USD: 10000.0,
    BTC: 0.5,
    ETH: 2.0,
    NAZA: 125.4,
  })

  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: "TX123456",
      type: "buy",
      asset: "BTC",
      amount: 0.05,
      price: 41250.75,
      total: 2062.54,
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    },
    {
      id: "TX123455",
      type: "sell",
      asset: "ETH",
      amount: 1.2,
      price: 2305.42,
      total: 2766.5,
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000),
    },
    {
      id: "TX123454",
      type: "buy",
      asset: "NAZA",
      amount: 50,
      price: 7.32,
      total: 366.0,
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
    },
  ])

  // Load from localStorage if available
  useEffect(() => {
    const savedBalances = localStorage.getItem("tradePro_balances")
    const savedTransactions = localStorage.getItem("tradePro_transactions")

    if (savedBalances) {
      try {
        setBalances(JSON.parse(savedBalances))
      } catch (e) {
        console.error("Failed to parse saved balances")
      }
    }

    if (savedTransactions) {
      try {
        const parsedTransactions = JSON.parse(savedTransactions)
        // Convert string timestamps back to Date objects
        parsedTransactions.forEach((tx: any) => {
          tx.timestamp = new Date(tx.timestamp)
        })
        setTransactions(parsedTransactions)
      } catch (e) {
        console.error("Failed to parse saved transactions")
      }
    }
  }, [])

  // Save to localStorage on update
  useEffect(() => {
    localStorage.setItem("tradePro_balances", JSON.stringify(balances))
    localStorage.setItem("tradePro_transactions", JSON.stringify(transactions))
  }, [balances, transactions])

  const addBalance = (currency: string, amount: number) => {
    setBalances((prev) => ({
      ...prev,
      [currency]: (prev[currency] || 0) + amount,
    }))
  }

  const subtractBalance = (currency: string, amount: number): boolean => {
    const currentBalance = balances[currency] || 0

    if (currentBalance < amount) {
      toast({
        title: "Insufficient balance",
        description: `You don't have enough ${currency} for this transaction.`,
        variant: "destructive",
      })
      return false
    }

    setBalances((prev) => ({
      ...prev,
      [currency]: currentBalance - amount,
    }))

    return true
  }

  const executeTrade = (type: "buy" | "sell", asset: string, amount: number, price: number): boolean => {
    const total = amount * price
    const fee = total * 0.001 // 0.1% fee
    const totalWithFee = type === "buy" ? total + fee : total - fee

    if (type === "buy") {
      // Check if user has enough USD
      if (!subtractBalance("USD", totalWithFee)) {
        return false
      }

      // Add the asset
      addBalance(asset, amount)
    } else {
      // Check if user has enough of the asset
      if (!subtractBalance(asset, amount)) {
        return false
      }

      // Add USD
      addBalance("USD", totalWithFee)
    }

    // Record the transaction
    const newTransaction: Transaction = {
      id: `TX${Date.now().toString().slice(-6)}`,
      type,
      asset,
      amount,
      price,
      total: totalWithFee,
      timestamp: new Date(),
    }

    setTransactions((prev) => [newTransaction, ...prev])

    return true
  }

  const getTransactions = () => {
    return transactions
  }

  return (
    <WalletContext.Provider
      value={{
        balances,
        transactions,
        addBalance,
        subtractBalance,
        executeTrade,
        getTransactions,
      }}
    >
      {children}
    </WalletContext.Provider>
  )
}

export const useWallet = () => {
  const context = useContext(WalletContext)
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider")
  }
  return context
}

