"use client"

import { ArrowDown, ArrowUp, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export function MarketOverview() {
  const markets = [
    { symbol: "NAZA/USD", name: "NazaCon", price: 8.76, change: 12.4, featured: true },
    { symbol: "BTC/USD", name: "Bitcoin", price: 42384.52, change: 2.4 },
    { symbol: "ETH/USD", name: "Ethereum", price: 2284.16, change: 3.1 },
    { symbol: "SOL/USD", name: "Solana", price: 102.75, change: 5.2 },
    { symbol: "ADA/USD", name: "Cardano", price: 0.58, change: -1.3 },
    { symbol: "DOT/USD", name: "Polkadot", price: 7.24, change: -0.8 },
    { symbol: "DOGE/USD", name: "Dogecoin", price: 0.12, change: 1.7 },
    { symbol: "LINK/USD", name: "Chainlink", price: 14.92, change: 4.5 },
    { symbol: "AVAX/USD", name: "Avalanche", price: 35.67, change: 2.9 },
  ]

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input type="search" placeholder="Search markets..." className="pl-8" />
      </div>
      <div className="rounded-md border">
        <div className="grid grid-cols-12 gap-2 p-3 text-sm font-medium text-muted-foreground border-b">
          <div className="col-span-5">Asset</div>
          <div className="col-span-4 text-right">Price</div>
          <div className="col-span-3 text-right">24h Change</div>
        </div>
        <div className="divide-y">
          {markets.map((market) => (
            <div
              key={market.symbol}
              className={`grid grid-cols-12 gap-2 p-3 text-sm hover:bg-muted/50 cursor-pointer ${market.featured ? "bg-primary/10 border-l-4 border-primary" : ""}`}
            >
              <div className="col-span-5">
                <div className="font-medium">{market.symbol}</div>
                <div className="text-xs text-muted-foreground">{market.name}</div>
              </div>
              <div className="col-span-4 text-right font-medium">
                ${market.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div
                className={`col-span-3 text-right font-medium flex items-center justify-end ${market.change >= 0 ? "text-emerald-500" : "text-rose-500"}`}
              >
                {market.change >= 0 ? <ArrowUp className="h-3 w-3 mr-1" /> : <ArrowDown className="h-3 w-3 mr-1" />}
                {Math.abs(market.change)}%
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

