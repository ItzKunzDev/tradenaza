"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function TradingChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const setCanvasDimensions = () => {
      const parent = canvas.parentElement
      if (!parent) return

      canvas.width = parent.clientWidth
      canvas.height = 400
    }

    setCanvasDimensions()
    window.addEventListener("resize", setCanvasDimensions)

    // Generate random price data
    const generatePriceData = (length: number, volatility: number) => {
      const startPrice = 42000 + Math.random() * 2000
      const prices = [startPrice]

      for (let i = 1; i < length; i++) {
        const change = (Math.random() - 0.48) * volatility
        const newPrice = prices[i - 1] * (1 + change)
        prices.push(newPrice)
      }

      return prices
    }

    const prices = generatePriceData(100, 0.01)

    // Draw the chart
    const drawChart = () => {
      if (!ctx) return

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Find min and max for scaling
      const minPrice = Math.min(...prices) * 0.999
      const maxPrice = Math.max(...prices) * 1.001
      const priceRange = maxPrice - minPrice

      // Draw grid
      ctx.strokeStyle = "#e2e8f0"
      ctx.lineWidth = 0.5

      // Horizontal grid lines
      for (let i = 0; i <= 5; i++) {
        const y = canvas.height - canvas.height * (i / 5)
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()

        // Price labels
        const price = minPrice + priceRange * (i / 5)
        ctx.fillStyle = "#64748b"
        ctx.font = "10px sans-serif"
        ctx.textAlign = "left"
        ctx.fillText(price.toFixed(2), 5, y - 5)
      }

      // Draw price line
      ctx.beginPath()
      ctx.strokeStyle = "#3b82f6"
      ctx.lineWidth = 2

      for (let i = 0; i < prices.length; i++) {
        const x = (i / (prices.length - 1)) * canvas.width
        const y = canvas.height - ((prices[i] - minPrice) / priceRange) * canvas.height

        if (i === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }

      ctx.stroke()

      // Draw area under the line
      ctx.lineTo(canvas.width, canvas.height)
      ctx.lineTo(0, canvas.height)
      ctx.closePath()

      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height)
      gradient.addColorStop(0, "rgba(59, 130, 246, 0.3)")
      gradient.addColorStop(1, "rgba(59, 130, 246, 0)")
      ctx.fillStyle = gradient
      ctx.fill()
    }

    drawChart()

    return () => {
      window.removeEventListener("resize", setCanvasDimensions)
    }
  }, [])

  return (
    <div className="flex flex-col">
      <div className="flex justify-between items-center px-6 py-2">
        <Tabs defaultValue="1d">
          <TabsList>
            <TabsTrigger value="1h">1H</TabsTrigger>
            <TabsTrigger value="4h">4H</TabsTrigger>
            <TabsTrigger value="1d">1D</TabsTrigger>
            <TabsTrigger value="1w">1W</TabsTrigger>
            <TabsTrigger value="1m">1M</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            Indicators
          </Button>
          <Button variant="outline" size="sm">
            Full Screen
          </Button>
        </div>
      </div>
      <div className="relative w-full h-[400px]">
        <canvas ref={canvasRef} className="w-full h-full"></canvas>
      </div>
    </div>
  )
}

