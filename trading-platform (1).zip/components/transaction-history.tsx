"use client"

import { useWallet } from "@/lib/wallet-context"

export function TransactionHistory() {
  const { transactions } = useWallet()

  // Format time from date
  const formatTime = (date: Date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (diffInSeconds < 60) return `${diffInSeconds} seconds ago`
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`
    return date.toLocaleDateString()
  }

  return (
    <div className="rounded-md border">
      <div className="grid grid-cols-12 gap-2 p-3 text-sm font-medium text-muted-foreground border-b">
        <div className="col-span-2">Type</div>
        <div className="col-span-2">Asset</div>
        <div className="col-span-2">Amount</div>
        <div className="col-span-2">Price</div>
        <div className="col-span-2">Total</div>
        <div className="col-span-2">Time</div>
      </div>
      <div className="divide-y max-h-[300px] overflow-y-auto">
        {transactions.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground">No transactions yet</div>
        ) : (
          transactions.map((tx) => (
            <div key={tx.id} className="grid grid-cols-12 gap-2 p-3 text-sm">
              <div
                className={`col-span-2 font-medium ${tx.type === "buy" || tx.type === "deposit" ? "text-emerald-500" : "text-rose-500"}`}
              >
                {tx.type.charAt(0).toUpperCase() + tx.type.slice(1)}
              </div>
              <div className="col-span-2">{tx.asset}</div>
              <div className="col-span-2">{tx.amount.toFixed(4)}</div>
              <div className="col-span-2">
                ${tx.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="col-span-2">
                ${tx.total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <div className="col-span-2 text-muted-foreground">{formatTime(tx.timestamp)}</div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}

