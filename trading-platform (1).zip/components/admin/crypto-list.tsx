"use client"

import type React from "react"

import { useState } from "react"
import { ArrowDown, ArrowUp, Edit, MoreHorizontal, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"

export function CryptoList() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [cryptocurrencies, setCryptocurrencies] = useState([
    { symbol: "NAZA/USD", name: "NazaCon", price: 8.76, change: 12.4, featured: true },
    { symbol: "BTC/USD", name: "Bitcoin", price: 42384.52, change: 2.4 },
    { symbol: "ETH/USD", name: "Ethereum", price: 2284.16, change: 3.1 },
    { symbol: "SOL/USD", name: "Solana", price: 102.75, change: 5.2 },
    { symbol: "ADA/USD", name: "Cardano", price: 0.58, change: -1.3 },
    { symbol: "DOT/USD", name: "Polkadot", price: 7.24, change: -0.8 },
    { symbol: "DOGE/USD", name: "Dogecoin", price: 0.12, change: 1.7 },
    { symbol: "LINK/USD", name: "Chainlink", price: 14.92, change: 4.5 },
    { symbol: "AVAX/USD", name: "Avalanche", price: 35.67, change: 2.9 },
  ])
  const [editCrypto, setEditCrypto] = useState<any>(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [cryptoToDelete, setCryptoToDelete] = useState<any>(null)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  const filteredCryptos = cryptocurrencies.filter(
    (crypto) =>
      crypto.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      crypto.symbol.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleEditCrypto = (crypto: any) => {
    setEditCrypto({ ...crypto })
  }

  const handleSaveEdit = () => {
    setCryptocurrencies(cryptocurrencies.map((crypto) => (crypto.symbol === editCrypto.symbol ? editCrypto : crypto)))

    toast({
      title: "Cryptocurrency updated",
      description: `${editCrypto.name} has been updated successfully.`,
    })

    setEditCrypto(null)
  }

  const handleDeleteCrypto = (crypto: any) => {
    setCryptoToDelete(crypto)
    setIsDeleteDialogOpen(true)
  }

  const confirmDelete = () => {
    setCryptocurrencies(cryptocurrencies.filter((crypto) => crypto.symbol !== cryptoToDelete.symbol))

    toast({
      title: "Cryptocurrency removed",
      description: `${cryptoToDelete.name} has been removed from the platform.`,
      variant: "destructive",
    })

    setIsDeleteDialogOpen(false)
    setCryptoToDelete(null)
  }

  const toggleFeatured = (symbol: string) => {
    setCryptocurrencies(
      cryptocurrencies.map((crypto) => (crypto.symbol === symbol ? { ...crypto, featured: !crypto.featured } : crypto)),
    )

    const crypto = cryptocurrencies.find((c) => c.symbol === symbol)

    toast({
      title: crypto?.featured ? "Removed from featured" : "Added to featured",
      description: `${crypto?.name} has been ${crypto?.featured ? "removed from" : "added to"} featured cryptocurrencies.`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Cryptocurrencies</CardTitle>
        <CardDescription>View and manage all cryptocurrencies on the platform</CardDescription>
        <div className="flex w-full max-w-sm items-center space-x-2 mt-2">
          <Input placeholder="Search cryptocurrencies..." value={searchQuery} onChange={handleSearch} />
          <Button>Search</Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Featured</TableHead>
              <TableHead>Symbol</TableHead>
              <TableHead>Name</TableHead>
              <TableHead className="text-right">Price (USD)</TableHead>
              <TableHead className="text-right">24h Change</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCryptos.map((crypto) => (
              <TableRow key={crypto.symbol}>
                <TableCell>
                  <Button
                    variant={crypto.featured ? "default" : "outline"}
                    size="sm"
                    onClick={() => toggleFeatured(crypto.symbol)}
                  >
                    {crypto.featured ? "Featured" : "Regular"}
                  </Button>
                </TableCell>
                <TableCell className="font-medium">{crypto.symbol}</TableCell>
                <TableCell>{crypto.name}</TableCell>
                <TableCell className="text-right">
                  $
                  {crypto.price.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </TableCell>
                <TableCell className={`text-right ${crypto.change >= 0 ? "text-emerald-500" : "text-rose-500"}`}>
                  {crypto.change >= 0 ? (
                    <ArrowUp className="h-3 w-3 inline mr-1" />
                  ) : (
                    <ArrowDown className="h-3 w-3 inline mr-1" />
                  )}
                  {Math.abs(crypto.change)}%
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Actions</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => handleEditCrypto(crypto)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => handleDeleteCrypto(crypto)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {/* Edit Dialog */}
        {editCrypto && (
          <Dialog open={!!editCrypto} onOpenChange={(open) => !open && setEditCrypto(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Cryptocurrency</DialogTitle>
                <DialogDescription>Make changes to the cryptocurrency details below.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="symbol" className="text-right">
                    Symbol
                  </Label>
                  <Input id="symbol" value={editCrypto.symbol} className="col-span-3" disabled />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Name
                  </Label>
                  <Input
                    id="name"
                    value={editCrypto.name}
                    onChange={(e) => setEditCrypto({ ...editCrypto, name: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="price" className="text-right">
                    Price (USD)
                  </Label>
                  <Input
                    id="price"
                    type="number"
                    value={editCrypto.price}
                    onChange={(e) =>
                      setEditCrypto({
                        ...editCrypto,
                        price: Number.parseFloat(e.target.value),
                      })
                    }
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="change" className="text-right">
                    24h Change (%)
                  </Label>
                  <Input
                    id="change"
                    type="number"
                    value={editCrypto.change}
                    onChange={(e) =>
                      setEditCrypto({
                        ...editCrypto,
                        change: Number.parseFloat(e.target.value),
                      })
                    }
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="featured" className="text-right">
                    Featured
                  </Label>
                  <div className="flex items-center space-x-2 col-span-3">
                    <Button
                      variant={editCrypto.featured ? "default" : "outline"}
                      size="sm"
                      onClick={() =>
                        setEditCrypto({
                          ...editCrypto,
                          featured: !editCrypto.featured,
                        })
                      }
                    >
                      {editCrypto.featured ? "Featured" : "Regular"}
                    </Button>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditCrypto(null)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveEdit}>Save changes</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}

        {/* Delete Confirmation Dialog */}
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
              <DialogDescription>
                Are you sure you want to remove {cryptoToDelete?.name} from the platform? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={confirmDelete}>
                Delete
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

