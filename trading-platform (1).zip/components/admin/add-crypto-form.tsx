"use client"

import type React from "react"

import { useState } from "react"
import { Save } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"

export function AddCryptoForm() {
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    symbol: "",
    name: "",
    price: "",
    change: "",
    marketCap: "",
    circulatingSupply: "",
    maxSupply: "",
    description: "",
    featured: false,
    launchDate: "",
    blockchain: "",
    consensus: "",
    website: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, featured: checked }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.symbol || !formData.name || !formData.price) {
      toast({
        title: "Missing required fields",
        description: "Please fill out all required fields.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Cryptocurrency added",
        description: `${formData.name} (${formData.symbol}) has been added to the platform.`,
      })

      // Reset form
      setFormData({
        symbol: "",
        name: "",
        price: "",
        change: "",
        marketCap: "",
        circulatingSupply: "",
        maxSupply: "",
        description: "",
        featured: false,
        launchDate: "",
        blockchain: "",
        consensus: "",
        website: "",
      })

      setIsSubmitting(false)
    }, 1500)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Cryptocurrency</CardTitle>
        <CardDescription>Add a new cryptocurrency to the trading platform</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="symbol">
                Symbol <span className="text-destructive">*</span>
              </Label>
              <Input
                id="symbol"
                name="symbol"
                value={formData.symbol}
                onChange={handleChange}
                placeholder="BTC/USD"
                required
              />
              <p className="text-xs text-muted-foreground">Trading symbol with base/quote currency (e.g., BTC/USD)</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">
                Name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Bitcoin"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="price">
                Price (USD) <span className="text-destructive">*</span>
              </Label>
              <Input
                id="price"
                name="price"
                type="number"
                step="0.00000001"
                value={formData.price}
                onChange={handleChange}
                placeholder="30000.00"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="change">24h Change (%)</Label>
              <Input
                id="change"
                name="change"
                type="number"
                step="0.1"
                value={formData.change}
                onChange={handleChange}
                placeholder="2.5"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="marketCap">Market Cap (USD)</Label>
              <Input
                id="marketCap"
                name="marketCap"
                value={formData.marketCap}
                onChange={handleChange}
                placeholder="500000000"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="circulatingSupply">Circulating Supply</Label>
              <Input
                id="circulatingSupply"
                name="circulatingSupply"
                value={formData.circulatingSupply}
                onChange={handleChange}
                placeholder="18000000"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxSupply">Max Supply</Label>
              <Input
                id="maxSupply"
                name="maxSupply"
                value={formData.maxSupply}
                onChange={handleChange}
                placeholder="21000000"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="launchDate">Launch Date</Label>
              <Input
                id="launchDate"
                name="launchDate"
                type="date"
                value={formData.launchDate}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="blockchain">Blockchain</Label>
              <Input
                id="blockchain"
                name="blockchain"
                value={formData.blockchain}
                onChange={handleChange}
                placeholder="Bitcoin"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="consensus">Consensus Mechanism</Label>
              <Input
                id="consensus"
                name="consensus"
                value={formData.consensus}
                onChange={handleChange}
                placeholder="Proof of Work"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website">Website URL</Label>
              <Input
                id="website"
                name="website"
                value={formData.website}
                onChange={handleChange}
                placeholder="https://example.com"
              />
            </div>

            <div className="flex items-center space-x-2 pt-4">
              <Switch id="featured" checked={formData.featured} onCheckedChange={handleSwitchChange} />
              <Label htmlFor="featured">Featured Cryptocurrency</Label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              placeholder="Enter a description of the cryptocurrency..."
              rows={5}
            />
          </div>

          <div className="rounded-md bg-muted p-4">
            <div className="flex items-center gap-2 text-sm">
              <span className="font-semibold">Note:</span>
              <span>
                Fields marked with <span className="text-destructive">*</span> are required.
              </span>
            </div>
          </div>
        </CardContent>

        <CardFooter className="flex justify-between">
          <Button variant="outline" type="button">
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Adding..." : "Add Cryptocurrency"}
            {!isSubmitting && <Save className="ml-2 h-4 w-4" />}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

