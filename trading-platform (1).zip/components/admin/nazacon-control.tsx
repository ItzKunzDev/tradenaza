"use client"

import { useState } from "react"
import { Save } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"

export function NazaconControl() {
  const { toast } = useToast()

  const [price, setPrice] = useState("8.76")
  const [marketCap, setMarketCap] = useState("876500000")
  const [circulatingSupply, setCirculatingSupply] = useState("100000000")
  const [maxSupply, setMaxSupply] = useState("250000000")
  const [liquidityLevel, setLiquidityLevel] = useState([60])
  const [volatilityLevel, setVolatilityLevel] = useState([20])
  const [autoMarketMaking, setAutoMarketMaking] = useState(true)
  const [tradingEnabled, setTradingEnabled] = useState(true)
  const [isLoading, setIsLoading] = useState(false)

  const handleSaveChanges = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Changes saved successfully",
        description: "NazaCon parameters have been updated.",
      })
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">NazaCon Control</h2>
          <p className="text-muted-foreground">Manage parameters and settings for the NazaCon cryptocurrency.</p>
        </div>
        <Button variant="default" onClick={handleSaveChanges} disabled={isLoading}>
          {isLoading ? "Saving..." : "Save All Changes"}
          {!isLoading && <Save className="ml-2 h-4 w-4" />}
        </Button>
      </div>

      <Tabs defaultValue="parameters">
        <TabsList>
          <TabsTrigger value="parameters">Market Parameters</TabsTrigger>
          <TabsTrigger value="algorithms">Trading Algorithms</TabsTrigger>
          <TabsTrigger value="restrictions">Restrictions</TabsTrigger>
        </TabsList>

        <TabsContent value="parameters" className="space-y-4 pt-4">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Price & Supply</CardTitle>
                <CardDescription>Control the price and supply parameters of NazaCon</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="current-price">Current Price (USD)</Label>
                  <Input id="current-price" type="text" value={price} onChange={(e) => setPrice(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="market-cap">Market Cap (USD)</Label>
                  <Input id="market-cap" type="text" value={marketCap} onChange={(e) => setMarketCap(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="circulating-supply">Circulating Supply</Label>
                  <Input
                    id="circulating-supply"
                    type="text"
                    value={circulatingSupply}
                    onChange={(e) => setCirculatingSupply(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max-supply">Max Supply</Label>
                  <Input id="max-supply" type="text" value={maxSupply} onChange={(e) => setMaxSupply(e.target.value)} />
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  variant="outline"
                  onClick={() => {
                    toast({
                      title: "Changes will be applied",
                      description: "Click 'Save All Changes' to confirm.",
                    })
                  }}
                >
                  Update Parameters
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Market Behavior</CardTitle>
                <CardDescription>Configure how NazaCon behaves in the market</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Liquidity Level</Label>
                    <span className="text-sm">{liquidityLevel}%</span>
                  </div>
                  <Slider value={liquidityLevel} max={100} step={1} onValueChange={setLiquidityLevel} />
                  <p className="text-xs text-muted-foreground">
                    Controls how easy it is to buy and sell large amounts without affecting the price.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Volatility Level</Label>
                    <span className="text-sm">{volatilityLevel}%</span>
                  </div>
                  <Slider value={volatilityLevel} max={100} step={1} onValueChange={setVolatilityLevel} />
                  <p className="text-xs text-muted-foreground">
                    Controls how much the price fluctuates in response to market activity.
                  </p>
                </div>

                <div className="flex items-center justify-between space-y-0 pt-2">
                  <Label htmlFor="auto-market-making">Automated Market Making</Label>
                  <Switch id="auto-market-making" checked={autoMarketMaking} onCheckedChange={setAutoMarketMaking} />
                </div>
                <div className="flex items-center justify-between space-y-0">
                  <Label htmlFor="trading-enabled">Trading Enabled</Label>
                  <Switch id="trading-enabled" checked={tradingEnabled} onCheckedChange={setTradingEnabled} />
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  variant="outline"
                  onClick={() => {
                    toast({
                      title: "Changes will be applied",
                      description: "Click 'Save All Changes' to confirm.",
                    })
                  }}
                >
                  Update Behavior
                </Button>
              </CardFooter>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Price Trend Simulation</CardTitle>
              <CardDescription>Set up simulated price trends for NazaCon</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="trend-direction">Trend Direction</Label>
                    <select
                      id="trend-direction"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="up">Upward</option>
                      <option value="down">Downward</option>
                      <option value="sideways">Sideways</option>
                      <option value="volatile">Volatile</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="trend-strength">Trend Strength (%)</Label>
                    <Input id="trend-strength" type="number" placeholder="10" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="trend-duration">Duration (hours)</Label>
                    <Input id="trend-duration" type="number" placeholder="24" />
                  </div>
                </div>

                <div className="h-[200px] w-full bg-muted rounded-md flex items-center justify-center">
                  <p className="text-muted-foreground">Price trend preview will appear here</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Reset to Default</Button>
              <Button
                onClick={() => {
                  toast({
                    title: "Trend simulation configured",
                    description: "The new price trend will be applied after saving all changes.",
                  })
                }}
              >
                Apply Trend
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="algorithms" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Trading Algorithms</CardTitle>
              <CardDescription>Configure automated trading algorithms for NazaCon</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="price-stabilization">Price Stabilization</Label>
                    <select
                      id="price-stabilization"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="off">Off</option>
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                    <p className="text-xs text-muted-foreground">
                      Controls how aggressively the system attempts to stabilize price fluctuations.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bot-trading">Bot Trading Intensity</Label>
                    <select
                      id="bot-trading"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="off">Off</option>
                      <option value="minimal">Minimal</option>
                      <option value="moderate">Moderate</option>
                      <option value="active">Active</option>
                    </select>
                    <p className="text-xs text-muted-foreground">
                      Sets the level of simulated trading activity from bots.
                    </p>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Trading Volume Boost</Label>
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm">
                      None
                    </Button>
                    <Button variant="outline" size="sm">
                      Low
                    </Button>
                    <Button variant="secondary" size="sm">
                      Medium
                    </Button>
                    <Button variant="outline" size="sm">
                      High
                    </Button>
                    <Button variant="outline" size="sm">
                      Very High
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Artificially increases the trading volume displayed on charts and statistics.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                onClick={() => {
                  toast({
                    title: "Algorithm settings updated",
                    description: "The new algorithm settings will be applied after saving all changes.",
                  })
                }}
              >
                Update Algorithms
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="restrictions" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Trading Restrictions</CardTitle>
              <CardDescription>Configure restrictions for NazaCon trading</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="min-order">Minimum Order Size (NAZA)</Label>
                  <Input id="min-order" type="number" placeholder="1" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max-order">Maximum Order Size (NAZA)</Label>
                  <Input id="max-order" type="number" placeholder="10000" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max-daily">Maximum Daily Purchase (NAZA)</Label>
                  <Input id="max-daily" type="number" placeholder="50000" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="price-limit">Price Change Limit (%)</Label>
                  <Input id="price-limit" type="number" placeholder="15" />
                  <p className="text-xs text-muted-foreground">Maximum allowed price change in a 24-hour period.</p>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="geo-restrictions">Geographic Restrictions</Label>
                  <Switch id="geo-restrictions" />
                </div>
                <p className="text-xs text-muted-foreground">Enable to restrict trading from specific regions.</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="kyc-required">KYC Required</Label>
                  <Switch id="kyc-required" />
                </div>
                <p className="text-xs text-muted-foreground">Require Know Your Customer verification before trading.</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                variant="outline"
                onClick={() => {
                  toast({
                    title: "Restrictions updated",
                    description: "The new restrictions will be applied after saving all changes.",
                  })
                }}
              >
                Update Restrictions
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

