"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import {
  ChevronRight,
  CreditCard,
  Landmark,
  Settings,
  BarChart3,
  Users,
  Coins,
  Database,
  ShieldAlert,
  Clock,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface AdminSidebarProps {
  className?: string
  activeItem: string
  setActiveItem: (item: string) => void
}

export function AdminSidebar({ className, activeItem, setActiveItem }: AdminSidebarProps) {
  const [collapsed, setCollapsed] = useState(false)

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setCollapsed(true)
      } else {
        setCollapsed(false)
      }
    }

    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const menuItems = [
    { id: "dashboard", name: "Dashboard", icon: BarChart3, href: "/admin" },
    { id: "cryptocurrencies", name: "Cryptocurrencies", icon: Coins, href: "/admin/cryptocurrencies" },
    { id: "users", name: "User Management", icon: Users, href: "/admin/users" },
    { id: "transactions", name: "Transactions", icon: CreditCard, href: "/admin/transactions" },
    { id: "deposits", name: "Deposits & Withdrawals", icon: Landmark, href: "/admin/deposits" },
    { id: "permissions", name: "Roles & Permissions", icon: ShieldAlert, href: "/admin/permissions" },
    { id: "logs", name: "System Logs", icon: Clock, href: "/admin/logs" },
    { id: "settings", name: "Platform Settings", icon: Settings, href: "/admin/settings" },
    { id: "database", name: "Database Management", icon: Database, href: "/admin/database" },
  ]

  return (
    <div
      className={cn(
        "bg-muted/30 border-r h-[calc(100vh-4rem)] hidden md:block w-64 overflow-y-auto transition-all duration-200 ease-in-out p-4",
        collapsed && "w-16",
        className,
      )}
    >
      <div className="space-y-1">
        {menuItems.map((item) => (
          <Link
            key={item.id}
            href={item.href}
            onClick={() => setActiveItem(item.id)}
            className={cn(
              "flex items-center rounded-md px-3 py-2 text-sm transition-colors",
              activeItem === item.id
                ? "bg-primary text-primary-foreground"
                : "hover:bg-muted text-muted-foreground hover:text-foreground",
            )}
          >
            <item.icon className="mr-2 h-4 w-4" />
            {!collapsed && <span>{item.name}</span>}
            {!collapsed && item.id === activeItem && <ChevronRight className="ml-auto h-4 w-4" />}
          </Link>
        ))}
      </div>
    </div>
  )
}

