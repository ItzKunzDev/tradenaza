"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { useWallet } from "@/lib/wallet-context"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

type OrderFormProps = {
  asset?: string
  defaultPrice?: string
}

export function OrderForm({ asset = "NAZA", defaultPrice = "8.76" }: OrderFormProps) {
  const { toast } = useToast()
  const { balances, executeTrade } = useWallet()

  const [orderType, setOrderType] = useState("market")
  const [amount, setAmount] = useState("1")
  const [price, setPrice] = useState(defaultPrice)
  const [sliderValue, setSliderValue] = useState([25])
  const [activeTab, setActiveTab] = useState("buy")
  const [isTrading, setIsTrading] = useState(false)
  const [showConfirmation, setShowConfirmation] = useState(false)

  const assetBalance = balances[asset] || 0
  const usdBalance = balances.USD || 0

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAmount(e.target.value)
  }

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPrice(e.target.value)
  }

  const handleSliderChange = (value: number[]) => {
    setSliderValue(value)

    if (activeTab === "buy") {
      // Calculate max NAZA that can be bought with current USD balance
      const maxBuyAmount = usdBalance / Number.parseFloat(price)
      const newAmount = ((value[0] / 100) * maxBuyAmount).toFixed(4)
      setAmount(newAmount)
    } else {
      // Calculate percentage of current NAZA balance
      const newAmount = ((value[0] / 100) * assetBalance).toFixed(4)
      setAmount(newAmount)
    }
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    // Reset slider and amount when changing tabs
    setSliderValue([25])
    if (value === "buy") {
      const maxBuyAmount = usdBalance / Number.parseFloat(price)
      setAmount(((25 / 100) * maxBuyAmount).toFixed(4))
    } else {
      setAmount(((25 / 100) * assetBalance).toFixed(4))
    }
  }

  const totalValue = Number.parseFloat(amount) * Number.parseFloat(price)
  const fee = totalValue * 0.001 // 0.1% fee
  const totalWithFee = activeTab === "buy" ? totalValue + fee : totalValue - fee

  const handleTrade = () => {
    if (isNaN(Number.parseFloat(amount)) || Number.parseFloat(amount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      })
      return
    }

    if (orderType !== "market" && (isNaN(Number.parseFloat(price)) || Number.parseFloat(price) <= 0)) {
      toast({
        title: "Invalid price",
        description: "Please enter a valid price",
        variant: "destructive",
      })
      return
    }

    setShowConfirmation(true)
  }

  const confirmTrade = () => {
    setIsTrading(true)
    setShowConfirmation(false)

    // Small delay to simulate processing
    setTimeout(() => {
      const success = executeTrade(
        activeTab as "buy" | "sell",
        asset,
        Number.parseFloat(amount),
        Number.parseFloat(price),
      )

      if (success) {
        toast({
          title: `${activeTab === "buy" ? "Purchase" : "Sale"} successful`,
          description: `${activeTab === "buy" ? "Bought" : "Sold"} ${Number.parseFloat(amount).toFixed(4)} ${asset} at $${Number.parseFloat(price).toFixed(2)}`,
        })

        // Reset amount after successful trade
        setAmount("1")
        setSliderValue([25])
      }

      setIsTrading(false)
    }, 1000)
  }

  return (
    <div className="space-y-4">
      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="buy">Buy</TabsTrigger>
          <TabsTrigger value="sell">Sell</TabsTrigger>
        </TabsList>
        <TabsContent value="buy" className="space-y-4 pt-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="order-type">Order Type</Label>
            </div>
            <select
              id="order-type"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              value={orderType}
              onChange={(e) => setOrderType(e.target.value)}
            >
              <option value="market">Market</option>
              <option value="limit">Limit</option>
              <option value="stop">Stop</option>
            </select>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="amount">Amount ({asset})</Label>
              <span className="text-xs text-muted-foreground">USD Balance: ${usdBalance.toFixed(2)}</span>
            </div>
            <Input id="amount" type="text" value={amount} onChange={handleAmountChange} />
          </div>

          {orderType !== "market" && (
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="price">Price (USD)</Label>
                <span className="text-xs text-muted-foreground">Current: ${Number.parseFloat(price).toFixed(2)}</span>
              </div>
              <Input id="price" type="text" value={price} onChange={handlePriceChange} />
            </div>
          )}

          <div className="space-y-2">
            <Label>Amount</Label>
            <Slider value={sliderValue} max={100} step={1} onValueChange={handleSliderChange} />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0%</span>
              <span>25%</span>
              <span>50%</span>
              <span>75%</span>
              <span>100%</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Total</span>
              <span>${totalValue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Fee (0.1%)</span>
              <span>${fee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm font-medium">
              <span>Total with Fee</span>
              <span>${totalWithFee.toFixed(2)}</span>
            </div>
          </div>

          <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={handleTrade} disabled={isTrading}>
            {isTrading ? "Processing..." : `Buy ${asset}`}
          </Button>
        </TabsContent>

        <TabsContent value="sell" className="space-y-4 pt-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="sell-order-type">Order Type</Label>
            </div>
            <select
              id="sell-order-type"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              value={orderType}
              onChange={(e) => setOrderType(e.target.value)}
            >
              <option value="market">Market</option>
              <option value="limit">Limit</option>
              <option value="stop">Stop</option>
            </select>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="sell-amount">Amount ({asset})</Label>
              <span className="text-xs text-muted-foreground">
                Balance: {assetBalance.toFixed(4)} {asset}
              </span>
            </div>
            <Input id="sell-amount" type="text" value={amount} onChange={handleAmountChange} />
          </div>

          {orderType !== "market" && (
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="sell-price">Price (USD)</Label>
                <span className="text-xs text-muted-foreground">Current: ${Number.parseFloat(price).toFixed(2)}</span>
              </div>
              <Input id="sell-price" type="text" value={price} onChange={handlePriceChange} />
            </div>
          )}

          <div className="space-y-2">
            <Label>Amount</Label>
            <Slider value={sliderValue} max={100} step={1} onValueChange={handleSliderChange} />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0%</span>
              <span>25%</span>
              <span>50%</span>
              <span>75%</span>
              <span>100%</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Total</span>
              <span>${totalValue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Fee (0.1%)</span>
              <span>${fee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm font-medium">
              <span>Total with Fee</span>
              <span>${totalWithFee.toFixed(2)}</span>
            </div>
          </div>

          <Button className="w-full bg-rose-600 hover:bg-rose-700" onClick={handleTrade} disabled={isTrading}>
            {isTrading ? "Processing..." : `Sell ${asset}`}
          </Button>
        </TabsContent>
      </Tabs>

      <AlertDialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm {activeTab === "buy" ? "Purchase" : "Sale"}</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to {activeTab === "buy" ? "buy" : "sell"} {Number.parseFloat(amount).toFixed(4)} {asset}
              at ${Number.parseFloat(price).toFixed(2)} per unit.
              <div className="mt-4 p-3 bg-muted rounded-md">
                <div className="flex justify-between text-sm font-medium">
                  <span>Amount:</span>
                  <span>
                    {Number.parseFloat(amount).toFixed(4)} {asset}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-medium">
                  <span>Price:</span>
                  <span>${Number.parseFloat(price).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm font-medium">
                  <span>Total with Fee:</span>
                  <span>${totalWithFee.toFixed(2)}</span>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmTrade}
              className={activeTab === "buy" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-rose-600 hover:bg-rose-700"}
            >
              Confirm {activeTab === "buy" ? "Purchase" : "Sale"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

