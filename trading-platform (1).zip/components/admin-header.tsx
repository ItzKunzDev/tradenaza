import Link from "next/link"
import { Bell, Search, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function AdminHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <span className="font-bold">TradePro</span>
            <span className="rounded-md bg-primary px-2 py-1 text-xs font-semibold text-primary-foreground">ADMIN</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
            <Link href="/admin" className="transition-colors hover:text-foreground/80">
              Dashboard
            </Link>
            <Link href="/admin/users" className="transition-colors hover:text-foreground/80">
              Users
            </Link>
            <Link href="/admin/settings" className="transition-colors hover:text-foreground/80">
              Settings
            </Link>
            <Link href="/admin/logs" className="transition-colors hover:text-foreground/80">
              Logs
            </Link>
          </nav>
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <form className="hidden md:flex">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search..." className="w-64 rounded-lg bg-background pl-8 md:w-80" />
            </div>
          </form>
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-primary"></span>
            <span className="sr-only">Notifications</span>
          </Button>
          <Button variant="ghost" size="icon">
            <User className="h-5 w-5" />
            <span className="sr-only">Account</span>
          </Button>
        </div>
      </div>
    </header>
  )
}

