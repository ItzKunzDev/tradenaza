"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell, Menu, Search, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { TradingChart } from "@/components/trading-chart"
import { OrderForm } from "@/components/order-form"
import { MarketOverview } from "@/components/market-overview"
import { TransactionHistory } from "@/components/transaction-history"
import { DepositModal } from "@/components/deposit-modal"
import { useWallet } from "@/lib/wallet-context"

export default function Dashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const { balances } = useWallet()

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <Button
            variant="ghost"
            size="icon"
            className="mr-2 md:hidden"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          >
            <Menu className="h-6 w-6" />
            <span className="sr-only">Toggle menu</span>
          </Button>
          <div className="mr-4 hidden md:flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="font-bold">TradeNaza</span>
            </Link>
            <nav className="flex items-center space-x-6 text-sm font-medium">
              <Link href="/dashboard" className="text-foreground transition-colors">
                Dashboard
              </Link>
              <Link href="/markets" className="transition-colors hover:text-foreground/80">
                Markets
              </Link>
              <Link href="/portfolio" className="transition-colors hover:text-foreground/80">
                Portfolio
              </Link>
              <Link href="/history" className="transition-colors hover:text-foreground/80">
                History
              </Link>
            </nav>
          </div>
          <div className="relative ml-auto flex items-center gap-4">
            <form className="hidden md:flex">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search markets..."
                  className="w-64 rounded-lg bg-background pl-8 md:w-80"
                />
              </div>
            </form>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-primary"></span>
              <span className="sr-only">Notifications</span>
            </Button>
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
              <span className="sr-only">Account</span>
            </Button>
          </div>
        </div>
      </header>
      <div
        className={`fixed inset-0 z-40 flex transform transition-transform duration-300 md:hidden ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="w-64 bg-background border-r">
          <div className="flex h-16 items-center border-b px-4">
            <Link href="/" className="flex items-center space-x-2">
              <span className="font-bold">TradeNaza</span>
            </Link>
          </div>
          <nav className="flex flex-col p-4 space-y-2 text-sm font-medium">
            <Link
              href="/dashboard"
              className="flex items-center space-x-2 rounded-lg bg-muted px-3 py-2 text-foreground"
            >
              Dashboard
            </Link>
            <Link href="/markets" className="flex items-center space-x-2 rounded-lg px-3 py-2 hover:bg-muted">
              Markets
            </Link>
            <Link href="/portfolio" className="flex items-center space-x-2 rounded-lg px-3 py-2 hover:bg-muted">
              Portfolio
            </Link>
            <Link href="/history" className="flex items-center space-x-2 rounded-lg px-3 py-2 hover:bg-muted">
              History
            </Link>
          </nav>
        </div>
        <div className="flex-1" onClick={() => setIsSidebarOpen(false)}></div>
      </div>
      <main className="flex-1 p-4 md:p-6">
        <div className="grid gap-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
              <p className="text-muted-foreground">Welcome back, your portfolio is up 3.5% today.</p>
            </div>
            <div className="flex items-center gap-2 mt-4 md:mt-0">
              <DepositModal />
              <Button size="sm">Trade Now</Button>
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${balances.USD.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-emerald-500 font-medium">↑ 3.5%</span> from yesterday
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">NAZA Balance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{balances.NAZA.toFixed(2)} NAZA</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-emerald-500 font-medium">↑ 12.4%</span> from yesterday
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Open Positions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">7</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-rose-500 font-medium">↓ 1</span> from yesterday
                </p>
              </CardContent>
            </Card>
          </div>
          <div className="grid gap-6 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>NAZA/USD</CardTitle>
                <CardDescription>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold">$8.76</span>
                    <span className="text-xs text-emerald-500 font-medium">↑ 12.4%</span>
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <TradingChart />
              </CardContent>
            </Card>
            <div className="flex flex-col gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Order Form</CardTitle>
                </CardHeader>
                <CardContent>
                  <OrderForm asset="NAZA" defaultPrice="8.76" />
                </CardContent>
              </Card>
            </div>
          </div>
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Market Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <MarketOverview />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <TransactionHistory />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

