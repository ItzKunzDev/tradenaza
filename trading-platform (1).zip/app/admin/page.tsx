"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronRight, Coins, LineChart, Settings, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdminHeader } from "@/components/admin-header"
import { AdminSidebar } from "@/components/admin-sidebar"
import { CryptoList } from "@/components/admin/crypto-list"
import { NazaconControl } from "@/components/admin/nazacon-control"
import { AddCryptoForm } from "@/components/admin/add-crypto-form"

export default function AdminDashboard() {
  const [activeSidebarItem, setActiveSidebarItem] = useState("dashboard")

  return (
    <div className="flex min-h-screen flex-col">
      <AdminHeader />
      <div className="flex flex-1">
        <AdminSidebar activeItem={activeSidebarItem} setActiveItem={setActiveSidebarItem} />
        <main className="flex-1 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Admin Dashboard</h1>
              <p className="text-muted-foreground">Manage your trading platform settings and assets.</p>
            </div>
            <Button asChild>
              <Link href="/dashboard">
                <span>View Trading Platform</span>
                <ChevronRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          <Tabs defaultValue="overview" className="mt-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="nazacon">NazaCon Control</TabsTrigger>
              <TabsTrigger value="cryptocurrencies">Cryptocurrencies</TabsTrigger>
              <TabsTrigger value="add-crypto">Add Cryptocurrency</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4 pt-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">1,274</div>
                    <p className="text-xs text-muted-foreground">
                      <span className="text-emerald-500">+12%</span> from last month
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Trading Volume (24h)</CardTitle>
                    <LineChart className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$1.2M</div>
                    <p className="text-xs text-muted-foreground">
                      <span className="text-emerald-500">+8%</span> from yesterday
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Listed Cryptocurrencies</CardTitle>
                    <Coins className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">9</div>
                    <p className="text-xs text-muted-foreground">
                      <span className="text-emerald-500">+1</span> new this week
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">NazaCon Price</CardTitle>
                    <Settings className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$8.76</div>
                    <p className="text-xs text-muted-foreground">
                      <span className="text-emerald-500">+12.4%</span> from yesterday
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
                <Card className="col-span-4">
                  <CardHeader>
                    <CardTitle>Platform Activity</CardTitle>
                  </CardHeader>
                  <CardContent className="pl-2">
                    <div className="h-[300px] w-full">
                      <img
                        src="/placeholder.svg?height=300&width=800"
                        alt="Activity Chart"
                        className="h-full w-full rounded-md object-cover"
                      />
                    </div>
                  </CardContent>
                </Card>
                <Card className="col-span-3">
                  <CardHeader>
                    <CardTitle>Market Distribution</CardTitle>
                    <CardDescription>Trading volume per cryptocurrency</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px] w-full">
                      <img
                        src="/placeholder.svg?height=300&width=400"
                        alt="Distribution Chart"
                        className="h-full w-full rounded-md object-cover"
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="nazacon" className="pt-4">
              <NazaconControl />
            </TabsContent>

            <TabsContent value="cryptocurrencies" className="pt-4">
              <CryptoList />
            </TabsContent>

            <TabsContent value="add-crypto" className="pt-4">
              <AddCryptoForm />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}

