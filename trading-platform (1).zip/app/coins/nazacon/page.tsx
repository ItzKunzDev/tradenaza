import Link from "next/link"
import { ArrowLeft, ArrowUp, ExternalLink, Share2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TradingChart } from "@/components/trading-chart"
import { OrderForm } from "@/components/order-form"

export default function NazaConPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <span className="font-bold">TradeNaza</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link href="/dashboard" className="transition-colors hover:text-foreground/80">
                Dashboard
              </Link>
              <Link href="/markets" className="transition-colors hover:text-foreground/80">
                Markets
              </Link>
              <Link href="/portfolio" className="transition-colors hover:text-foreground/80">
                Portfolio
              </Link>
              <Link href="/history" className="transition-colors hover:text-foreground/80">
                History
              </Link>
            </nav>
          </div>
          <div className="ml-auto flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Share2 className="h-5 w-5" />
              <span className="sr-only">Share</span>
            </Button>
            <Button variant="outline" size="sm">
              Add to Watchlist
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="grid gap-6">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" asChild className="mr-2">
              <Link href="/dashboard">
                <ArrowLeft className="h-5 w-5" />
                <span className="sr-only">Back</span>
              </Link>
            </Button>
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20">
                <span className="text-lg font-bold text-primary">NZCO</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight">NazaCon (NZCO)</h1>
                <div className="flex items-center gap-2">
                  <span className="text-xl font-semibold">$8.76</span>
                  <span className="flex items-center text-sm font-medium text-emerald-500">
                    <ArrowUp className="mr-1 h-4 w-4" />
                    12.4%
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>NZCO/USD</CardTitle>
                <CardDescription>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold">$8.76</span>
                    <span className="text-xs text-emerald-500 font-medium">↑ 12.4%</span>
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <TradingChart />
              </CardContent>
            </Card>
            <div className="flex flex-col gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Order Form</CardTitle>
                </CardHeader>
                <CardContent>
                  <OrderForm />
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>About NazaCon</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p>
                    NazaCon (NAZA) is an innovative cryptocurrency designed for next-generation digital transactions.
                    Launched in 2023, NazaCon utilizes advanced blockchain technology to provide secure, fast, and
                    low-cost transactions across the globe.
                  </p>
                  <p>
                    With its unique consensus mechanism and smart contract capabilities, NazaCon aims to revolutionize
                    how digital assets are exchanged and utilized in everyday applications.
                  </p>
                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Market Cap</h3>
                      <p className="text-lg font-semibold">$876,500,000</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">24h Volume</h3>
                      <p className="text-lg font-semibold">$124,350,000</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Circulating Supply</h3>
                      <p className="text-lg font-semibold">100,000,000 NZCO</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Max Supply</h3>
                      <p className="text-lg font-semibold">250,000,000 NZCO</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <Button variant="outline" size="sm" className="gap-2">
                      <ExternalLink className="h-4 w-4" />
                      Visit Website
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>NazaCon Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">All-time high</span>
                    <span className="font-medium">$12.45</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">All-time low</span>
                    <span className="font-medium">$1.20</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">30d change</span>
                    <span className="font-medium text-emerald-500">+45.8%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">90d change</span>
                    <span className="font-medium text-emerald-500">+120.5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Launch date</span>
                    <span className="font-medium">Mar 15, 2023</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Blockchain</span>
                    <span className="font-medium">NazaChain</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Consensus</span>
                    <span className="font-medium">Proof of Stake</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Price History</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="7d">
                <TabsList>
                  <TabsTrigger value="24h">24h</TabsTrigger>
                  <TabsTrigger value="7d">7d</TabsTrigger>
                  <TabsTrigger value="30d">30d</TabsTrigger>
                  <TabsTrigger value="90d">90d</TabsTrigger>
                  <TabsTrigger value="1y">1y</TabsTrigger>
                  <TabsTrigger value="all">All</TabsTrigger>
                </TabsList>
                <TabsContent value="7d" className="pt-4">
                  <div className="h-[300px] w-full bg-muted/30 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">NazaCon 7-day price chart</p>
                      <p className="text-xs text-muted-foreground">+18.5% in the last 7 days</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="24h" className="pt-4">
                  <div className="h-[300px] w-full bg-muted/30 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">NazaCon 24-hour price chart</p>
                      <p className="text-xs text-muted-foreground">+12.4% in the last 24 hours</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="30d" className="pt-4">
                  <div className="h-[300px] w-full bg-muted/30 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">NazaCon 30-day price chart</p>
                      <p className="text-xs text-muted-foreground">+45.8% in the last 30 days</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="90d" className="pt-4">
                  <div className="h-[300px] w-full bg-muted/30 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">NazaCon 90-day price chart</p>
                      <p className="text-xs text-muted-foreground">+120.5% in the last 90 days</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="1y" className="pt-4">
                  <div className="h-[300px] w-full bg-muted/30 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">NazaCon 1-year price chart</p>
                      <p className="text-xs text-muted-foreground">+350.2% in the last year</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="all" className="pt-4">
                  <div className="h-[300px] w-full bg-muted/30 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">NazaCon all-time price chart</p>
                      <p className="text-xs text-muted-foreground">+630.0% since launch</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

